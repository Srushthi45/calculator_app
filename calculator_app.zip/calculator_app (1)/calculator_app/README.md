# Calculator App

A simple calculator application built using Python and Tkinter.

## Features
- Basic operations: Add, Subtract, Multiply, Divide
- Clear function
- User-friendly GUI

## How to Run
```bash
python main.py
```
